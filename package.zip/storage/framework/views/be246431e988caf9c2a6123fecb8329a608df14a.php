<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <div id="app">
<div class="container-fluid" style="text-align: left; color: #000;">
  <div class="row">
    <div class="col-2">
      <?php echo $__env->make('inc.admin-sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-10">
        <?php echo $__env->make('inc.admin-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="create-user">
    <div class="container">
    <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row justify-content-center">
            <div class="col-9">
                <div class="card">
                    <div class="card-header">Reset User Password</div>
    
                    <div class="card-body">
                        
                      <form action="/admin/users/processResetPass" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="password" class="col-md-2 col-form-label text-md-right">Password</label>
    
                            <div class="col-9">
                                <input id="password" type="password" class="form-control" name="password" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="passwordCon" class="col-md-2 col-form-label text-md-right">Confirm Password</label>
    
                            <div class="col-9">
                                <input id="passwordCon" type="password" class="form-control" name="passwordCon" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Reset Password</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\Programming\xampp\htdocs\pca\resources\views/admin/users/resetPass.blade.php ENDPATH**/ ?>