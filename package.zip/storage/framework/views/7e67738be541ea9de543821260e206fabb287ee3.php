<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<script>
    $.ajaxSetup({
	headers: {
		'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	        }
});

$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
});

  $(document).ready(function(){
    $('#user-role').change(function(){
        $.ajax({
        type: 'post',
        url: '/admin/role',
        data: $('#role').serialize(),
        success: function () {
            alert('form was submitted');
        }
      //console.log('Hello world');
    });
});
  });
</script>
</head><?php /**PATH E:\Programming\xampp\htdocs\pca\resources\views/inc/ajax.blade.php ENDPATH**/ ?>