
<?php $__env->startSection('content'); ?>
<div id="work">
        <h1>Our Work</h1>
        <?php if(count($news) > 0): ?>
        <div class="container">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="media">
                <img class="mr-3" src="img/pcaLogo.png" alt="Generic placeholder image" style="height: 120px; width:120px;">
                <div class="media-body">
                  <h5 class="mt-0"><?php echo e($story->title); ?></h5>
                  <?php echo e($story->story); ?>

                  <p>Written on: <?php echo e($story->created_at); ?></p>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
              <?php endif; ?>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Programming\xampp\htdocs\pca\resources\views/news/index.blade.php ENDPATH**/ ?>