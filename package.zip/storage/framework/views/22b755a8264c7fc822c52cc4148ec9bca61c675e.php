
<?php $__env->startSection('content'); ?>
<div class="container">
    <div id="add-event-form">
<h1>Add new Event</h1>
<?php echo Form::open(['method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="form-group">
        <?php echo e(Form::label('title', 'Event Title')); ?>

        <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Enter Event Title...'])); ?>

        <?php echo e(Form::label('description', 'Event Description')); ?>

        <?php echo e(Form::textarea('description', '', ['class' => 'form-control', 'placeholder' => 'Enter Event Description...'])); ?>

        <?php echo e(Form::label('date', 'Event Date')); ?>

        <?php echo e(Form::date('date', '', ['class' => 'form-control', 'placeholder' => 'Select Event Date...'])); ?>

        <?php echo e(Form::label('time', 'Event Time')); ?>

        <?php echo e(Form::time('time', '', ['class' => 'form-control', 'placeholder' => 'Enter Event Time...'])); ?>

        <?php echo e(Form::label('location', 'Event Location')); ?>

        <?php echo e(Form::text('location', '', ['class' => 'form-control', 'placeholder' => 'Enter Event Location...'])); ?>

        <?php echo e(Form::label('managed_by', 'Event Managed By')); ?>

        <?php echo e(Form::text('managed_by', '', ['class' => 'form-control', 'placeholder' => 'Who Is Managing The Event...'])); ?>

        <?php echo e(Form::label('title', 'Event Image')); ?>

        <?php echo e(Form::file('image', ['class' => 'btn btn-default'])); ?>

    </div>
    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

<?php echo Form::close(); ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Programming\xampp\htdocs\pca\resources\views/events/create.blade.php ENDPATH**/ ?>