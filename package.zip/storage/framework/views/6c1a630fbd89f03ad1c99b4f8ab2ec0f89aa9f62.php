<h1><?php echo e($event->title); ?></h1>
<?php /**PATH E:\Programming\xampp\htdocs\pca\resources\views/events/show.blade.php ENDPATH**/ ?>