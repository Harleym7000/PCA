
<?php $__env->startSection('content'); ?>
        <div class="index container-fluid">
            <img src="img/IMG_20190803_163241.jpg" alt="portstewart" style="width:100%;" class="bg-image">
            <div class="centered">
                <h1>Insert PCA Mission Statement Here</h1>
                <div class="row justify-content-center">
                <a href="/register"><button type="button" class="btn btn-primary">JOIN TODAY</button></a>
                <a href="/about"><button type="button" class="btn btn-outline-light">FIND OUT MORE</button></a>
            </div>
          </div>
          </div>
          <div id="events">
              <h1>Upcoming Events</h1>
              <div class="row justify-content-center">
                  <?php if(count($events) > 0): ?>
                  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 25rem;">
                    <img src="img/pcaLogo.png" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($event->title); ?></h5>
                      <p class="card-text"><?php echo e($event->date); ?> - <?php echo e($event->time); ?></p>
                      <p class="card-text"><?php echo e($event->venue); ?></p>
                      <a href="/event/<?php echo e($event->id); ?>" class="btn btn-primary">Find Out More <svg class="bi bi-arrow-bar-right" width="1.2em" height="1.2em" viewBox="0 0 16 16" fill="white" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M10.146 4.646a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L12.793 8l-2.647-2.646a.5.5 0 0 1 0-.708z"/>
                        <path fill-rule="evenodd" d="M6 8a.5.5 0 0 1 .5-.5H13a.5.5 0 0 1 0 1H6.5A.5.5 0 0 1 6 8zm-2.5 6a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 1 0v11a.5.5 0 0 1-.5.5z"/>
                      </svg></a>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?> 
                  <p>There are currently no Upcoming Events</p>
                  <?php endif; ?>
              </div>
              <div id="all-events" class="justify-content-center">
              <a href="/events"><button type="button" class="btn btn-primary">View all Events!</button></a>
          </div>
          </div>
          <div id="news">
            <h1>Latest News</h1>
            <?php if(count($news) > 0): ?>
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="media">
              <img class="media-object mr-3" src="img/pcaLogo.png" alt="Generic placeholder image" style="height: 240px; width:180px;">
              <div class="media-body">
                <a href=""><h5 class="mt-0"><?php echo e($story->title); ?></h5></a>
                <?php echo e($story->story); ?>

                <br><br>
                <p>Written on: <?php echo e($story->created_at); ?></p>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Programming\xampp\htdocs\pca\resources\views/pages/index.blade.php ENDPATH**/ ?>