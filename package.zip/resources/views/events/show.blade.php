<h1>{{$event->title}}</h1>
