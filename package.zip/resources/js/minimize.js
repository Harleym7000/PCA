
function minimize() {
    document.getElementsByClassName('col-2').className('col-1');
}
